<?php
session_start();

// ตรวจสอบว่ามีการเข้าสู่ระบบหรือไม่
if (!isset($_SESSION['username'])) {
    // หากไม่ได้เข้าสู่ระบบ ให้ redirect ไปยังหน้า login.php
    header("Location: login_form.html");
    exit; // จบการทำงานของสคริปต์ทันทีหลังจาก redirect
}
include 'db_connect.php';
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>แก้ไขรายการซ่อม</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        // เมื่อกดปุ่ม "SAVE" ให้แสดง Popup แจ้งเตือน
        function showAlert() {
            alert("บันทึกสำเร็จ!");
        }
    </script>
</head>

<body>
    <?php
    include 'db_connect.php';
    //ไอดีที่ส่งมา
    $id = $_GET['id'];
    $query = "SELECT * FROM repair_requests WHERE id=$id";
    $result = mysqli_query($db_connect, $query) or die
        ("Error in sql : $query" . mysqli_error($query));
    $row = mysqli_fetch_array($result);
    ?>

    <?php include 'navbar.php'; ?>
    <center>
        <img src="banner.png" alt="BANNER" class="center img-responsive">
    </center>
    <table>
        <center>
            <div class="container">
                <div class="row ustify-content-center">
                    <div class="row">
                    </div>
                    <center>
                        <h1>แก้ไขรายการซ่อม</h1>
                        <form action="edit_requests_db_admin.php" method="post">
                            <div class="form-group">
                                <label for="inputid" class="<col-md-8> control-label">
                                    <center>ID</center>
                                </label>
                                <div class="<col-md-12>">
                                    <input type="number" name="id" class="form-control"
                                        value="<?php echo $row['id']; ?>" readonly>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputname" class="<col-md-8> control-label">
                                    <center>ชื่อบุคคลแจ้ง</center>
                                </label>
                                <div class="<col-md-12>">
                                    <input type="text" name="name" class="form-control" require
                                        value="<?php echo $row['name']; ?>" readonly>

                                </div>
                            </div>

                            <div class="form-group">
                                <label for="status" class="<col-md-8> control-label">
                                    <center>สถานะการซ่อม</center>
                                </label>
                                <div class="<col-md-12>">
                                    <select required name="status" class="form-control">
                                        <option value="" selected disabled>เลือกสถานะการซ่อม</option>
                                        <option value="เสร็จสิ้น">เสร็จสิ้น</option>
                                        <option value="ไม่สามารถซ่อมได้">ไม่สามารถซ่อมได้</option>
                                        <option value="กำลังซ่อม">กำลังซ่อม</option>
                                        <option value="รับงานซ่อมแล้ว">รับงานซ่อมแล้ว</option>
                                    </select>
                                </div>
                            </div>
                    </center>
                        <div class="form-group">
                            <div class="col-sm-offset-2 col-sm-12">
                            </div>
                            <button class="btn btn-success" type="submit" onclick="showAlert()">SAVE</button>
                        </div>
                        </form>
                    <br>
</br>
      <center>
    <img src="footer.png" alt="footer" class="center img-responsive">
  </center>
    </table>
</body>

</html>
