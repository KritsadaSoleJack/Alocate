<?php
session_start();

// ตรวจสอบว่ามีการเข้าสู่ระบบหรือไม่
if (!isset($_SESSION['username'])) {
    // หากไม่ได้เข้าสู่ระบบ ให้ redirect ไปยังหน้า login.php
    header("Location: login_form.html");
    exit; // จบการทำงานของสคริปต์ทันทีหลังจาก redirect
}
include 'db_connect.php';
// กำหนดจำนวนรายการต่อหน้า
$items_per_page = 10;

// หาจำนวนข้อมูลทั้งหมด
$total_items_query = "SELECT COUNT(*) AS total FROM repair_requests";
$total_items_result = mysqli_query($db_connect, $total_items_query);
$total_items_row = mysqli_fetch_assoc($total_items_result);
$total_items = $total_items_row['total'];

// หาจำนวนหน้าทั้งหมด
$total_pages = ceil($total_items / $items_per_page);

// หาหน้าปัจจุบัน
$current_page = isset($_GET['page']) ? $_GET['page'] : 1;

// คำนวณ offset
$offset = ($current_page - 1) * $items_per_page;

// สร้างคำสั่ง SQL สำหรับแสดงข้อมูลในหน้าปัจจุบัน
$query = "SELECT * FROM repair_requests LIMIT $items_per_page OFFSET $offset";

$result = mysqli_query($db_connect, $query) or die("Error in sql : $query" . mysqli_error($db_connect));
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>
    <?php include 'navbar.php'; ?>
    <center>
        <img src="banner.png" alt="BANNER" class="center img-responsive">
    </center>
    <div class="container table-container">
        <div class="row">
            <div class="col-12 col-md-12">
                <table class="table table-striped table-bordered table-hover">
                    <h1>
                        <center>แสดงรายการซ่อม<br></center>
                    </h1>
                    <thead>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>ปัญหา</th>
                        <th>รหัสอุปกรณ์</th>
                        <th>ประเภทอุปกรณ์</th>
                        <th>ห้อง</th>
                        <th>Status</th>
                        <th>วันที่ลงทะเบียน</th>
                        <th>Edit</th>
                        <th>Delete</th>

                    </thead>
                    <?php
                    foreach ($result as $row) { ?>
                        <tr>
                            <td>
                                <?php echo $row['id']; ?>
                            </td>
                            <td>
                                <?php echo $row['name']; ?>
                            </td>
                            <td>
                                <?php echo $row['email']; ?>
                            </td>
                            <td>
                                <?php echo $row['issue']; ?>
                            </td>
                            <td>
                                <?php echo $row['device_code']; ?>
                            </td>
                            <td>
                                <?php echo $row['device_type']; ?>
                            </td>
                            <td>
                                <?php echo $row['room']; ?>
                            </td>
                            <td>
                                <?php echo $row['status']; ?>
                            </td>
                            <td>
                                <?php echo $row['submitted_at']; ?>
                            </td>

                            <td>
                                <a href="edit_page_request.php?id=<?php echo $row['id']; ?>" class="btn btn-success"
                                    role="button">Edit</a>
                            </td>

                            <td>
                                <a href="delete_requests.php?id=<?php echo $row['id']; ?>" class="btn btn-danger"
                                    role="button">Delete</a>
                            </td>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php mysqli_close($db_connect) ?>
    <center>
        <!-- สร้างลิงก์ไปยังหน้าถัดไปและหน้าก่อนหน้า -->
        <div class="pagination justify-content-center">
            <?php if ($current_page > 1): ?>
                <a href="?page=<?php echo $current_page - 1; ?>" class="btn btn-primary">&laquo; Previous</a>
            <?php endif; ?>

            <?php for ($page = 1; $page <= $total_pages; $page++): ?>
                <a href="?page=<?php echo $page; ?>"
                    class="btn btn-primary <?php echo ($page == $current_page) ? 'active' : ''; ?>">
                    <?php echo $page; ?>
                </a>
            <?php endfor; ?>

            <?php if ($current_page < $total_pages): ?>
                <a href="?page=<?php echo $current_page + 1; ?>" class="btn btn-primary">Next &raquo;</a>
            <?php endif; ?>
        </div>
    </center>
    <br>
    <center>
        <img src="footer.png" alt="footer" class="center img-responsive">
    </center>
</body>

</html>
