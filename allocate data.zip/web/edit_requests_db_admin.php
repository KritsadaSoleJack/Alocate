<?php
include 'db_connect.php';

$original_id = $_POST['id']; // เก็บ ID ต้นฉบับ
$status = $_POST['status'];

// อัปเดตข้อมูลเฉพาะสถานะการซ่อม
$sql = "UPDATE repair_requests SET 
        status = '$status'
        WHERE id = $original_id";

$result = mysqli_query($db_connect, $sql) or die("Error in sql : $sql" . mysqli_error($db_connect));

mysqli_close($db_connect);

if ($result) {
    // เซ็ตค่า session เพื่อแสดงข้อความแจ้งเตือน
    session_start();
    $_SESSION['update_success'] = true;

    // นำกลับไปยังหน้าแสดงข้อมูลหลังจากอัปเดตสำเร็จ
    header("Location: manage_repair_status.php");
    exit;
} else {
    // หากเกิดข้อผิดพลาดในการอัปเดต
    echo "<script type='text/javascript'>";
    echo "alert('Error in updating data!');";
    echo "window.location = 'manage_repair_status.php';";
    echo "</script>";
}
?>
