<?php
include 'db_connect.php';

$original_id = $_POST['id']; // เก็บ ID ต้นฉบับ
$name = $_POST['name'];
$email = $_POST['email'];
$issue = $_POST['issue'];
$device_code = $_POST['device_code'];
$device_type = $_POST['device_type'];
$room = $_POST['room'];

// อัปเดตข้อมูลทั้งหมด
$sql = "UPDATE repair_requests SET
            email='$email',
            issue='$issue',
            device_code='$device_code',
            device_type='$device_type'
        WHERE id = $original_id";

$result = mysqli_query($db_connect, $sql) or die("Error in sql : $sql" . mysqli_error($db_connect));

mysqli_close($db_connect);

if ($result) {
    echo "<script type='text/javascript'>";
    echo "alert('Update Successfully!');";
    echo "window.location = 'edit_page_request.php';";
    echo "</script>";
} else {
    echo "<script type='text/javascript'>";
    echo "alert('Error!');";
    echo "window.location = 'edit_page_request.php';";
    echo "</script>";
}
?>
