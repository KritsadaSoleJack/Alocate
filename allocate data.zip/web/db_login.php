<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "k_login";

$db_login = new mysqli($host, $username, $password, $database);

if ($db_login->connect_error) {
    die("Connection failed: " . $db_login->connect_error);
}
?>
