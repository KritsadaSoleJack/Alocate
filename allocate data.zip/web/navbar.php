<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Allocate data</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li <?php echo (basename($_SERVER['PHP_SELF']) == 'index.php') ? 'class="active"' : ''; ?>><a href="index.php">Home</a></li>
        <li <?php echo (basename($_SERVER['PHP_SELF']) == 'Show.php') ? 'class="active"' : ''; ?>><a href="Show.php">แสดงข้อมูล</a></li>
        <li <?php echo (basename($_SERVER['PHP_SELF']) == 'Add_page.php') ? 'class="active"' : ''; ?>><a href="Add_page.php">เพิ่มข้อมูล</a></li>
        <li <?php echo (basename($_SERVER['PHP_SELF']) == 'repair_list.php') ? 'class="active"' : ''; ?>><a href="repair_list.php">แสดงรายการซ่อม</a></li>
        <li <?php echo (basename($_SERVER['PHP_SELF']) == 'repair_form.php') ? 'class="active"' : ''; ?>><a href="repair_form.php">เพิ่มข้อมูลการซ่อม</a></li>
      </ul>
      <?php
        if (isset($_SESSION['level']) && $_SESSION['level'] == 'ADMIN') {
          echo "<ul class='nav navbar-nav navbar-right'>";
          echo "<li><a href='manage_repair_status.php'>จัดการงานซ่อม</a></li>";
          echo "</ul>";
        }
      ?>
      <ul class="nav navbar-nav navbar-right">
        <?php
          if (isset($_SESSION['username'])) {
            $username = $_SESSION['username'];
            echo "<li><a href='#'><span class='glyphicon glyphicon-user'></span> $username</a></li>";
            echo "<li><a href='logout.php'><span class='glyphicon glyphicon-log-out'></span> Logout</a></li>";
          } else {
            echo "<li><a href='#'><span class='glyphicon glyphicon-search'></span> Search</a></li>";
            echo "<li><a href='signup.php'><span class='glyphicon glyphicon-user'></span> Sign Up</a></li>";
            echo "<li><a href='login_form.html'><span class='glyphicon glyphicon-log-in'></span> Login</a></li>";
          }
        ?>
      </ul>
    </div>
  </div>
</nav>
