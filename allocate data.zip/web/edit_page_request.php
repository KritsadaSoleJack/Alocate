<?php
session_start();

// ตรวจสอบว่ามีการเข้าสู่ระบบหรือไม่
if (!isset($_SESSION['username'])) {
    // หากไม่ได้เข้าสู่ระบบ ให้ redirect ไปยังหน้า login.php
    header("Location: login_form.html");
    exit; // จบการทำงานของสคริปต์ทันทีหลังจาก redirect
}
include 'db_connect.php';

// ตรวจสอบว่ามีคีย์ "id" ในอาร์เรย์ $_GET หรือไม่
if (!isset($_GET['id'])) {
    echo "ID is missing.";
    exit;
}

// ไอดีที่ส่งมา
$id = $_GET['id'];
$query = "SELECT * FROM repair_requests WHERE id=$id";
$result = mysqli_query($db_connect, $query) or die
    ("Error in sql : $query" . mysqli_error($db_connect));
$row = mysqli_fetch_array($result);
?>

<!doctype html>
<html lang="en">

<head>
    <title>แก้ไขรายการซ่อม</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>

    <?php include 'navbar.php'; ?>
    <center>
        <img src="banner.png" alt="BANNER" class="center img-responsive">
    </center>

    <div class="container">
        <h1 class="text-center">แก้ไขรายการซ่อม</h1>
        <form action="edit_page_request_db.php" method="post">
            <div class="form-group">
                <label for="inputid" class="col-md-8 control-label">ID</label>
                <div class="col-md-12">
                    <input type="number" name="id" class="form-control" value="<?php echo $row['id']; ?>" readonly>
                </div>
            </div>
            <div class="form-group">
                <label for="inputname" class="col-md-8 control-label">ชื่อบุคคลแจ้ง</label>
                <div class="col-md-12">
                    <input type="text" name="name" class="form-control" required value="<?php echo $row['name']; ?>">
                </div>
            </div>
            <div class="form-group">
                <label for="inputemail" class="col-md-8 control-label">Email</label>
                <div class="col-md-12">
                    <input type="text" name="email" class="form-control" required value="<?php echo $row['email']; ?>">
                </div>
            </div>
            <div class="form-group">
                <label for="inputcode_device" class="col-md-8 control-label">รหัสอุปกรณ์</label>
                <div class="col-md-12">
                    <input type="text" name="device_code" class="form-control" required
                        value="<?php echo $row['device_code']; ?>">
                </div>
            </div>
            <div class="form-group">
                <label for="inputissue" class="col-md-8 control-label">ปัญหาที่แจ้ง</label>
                <div class="col-md-12">
                    <input type="text" name="issue" class="form-control" required value="<?php echo $row['issue']; ?>">
                </div>
            </div>
            <div class="form-group">
                <label for="inputType_Device" class="col-md-8 control-label">Type Device</label>
                <div class="col-md-12">
                    <select required name="Type_Device" id="Type_Device" class="form-control">
                        <option value="" selected disabled>ชนิดอุปกรณ์</option>
                        <option value="เมาส์(Mouse)">เมาส์(Mouse)</option>
                        <option value="จอแสดงผล(Monitor)">จอแสดงผล(Monitor)</option>
                        <option value="คีย์บอร์ด(Keyboard)">คีย์บอร์ด(Keyboard)</option>
                        <option value="คอมพิวเตอร์(Computer)">คอมพิวเตอร์(Computer)</option>
                        <option value="Smartphone">โทรศัพท์(Smartphone)</option>
                        <option value="Scanner">เครื่องถ่ายเอกสาร(Scanner)</option>
                        <option value="Tablet">แท็บเล็ต(Tablet)</option>
                        <option value="Laptop">โน้ตบุ้ค(Laptop)</option>
                        <option value="Projector">โปรเจ็คเตอร์(Projector)</option>
                        <option value="Printer">เครื่องปริ้น(Printer)</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="inputRoom" class="col-md-8 control-label">Room</label>
                <div class="col-md-12">
                    <select required name="room" id="room" class="form-control">
                        <option value="" selected disabled>ห้อง</option>
                        <option value="Com1">Com1</option>
                        <option value="Com2">Com2</option>
                        <option value="Com3">Com3</option>
                        <option value="Com4">Com4</option>
                    </select>
                </div>
            </div>
            <center>
                                <div class="form-group">
                                    <div class="col-sm-offset-2 col-sm-12">
                                    </div>
                                    <button class="btn btn-success" type="submit" class="btn btn-default">SAVE</button>
                                </div>
                        </form>
                    </CENTER>

        </form>
    </div>
    <br>
    </br>
    <center>
        <img src="footer.png" alt="footer" class="center img-responsive">
    </center>
</body>

</html>