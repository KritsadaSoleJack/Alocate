<?php
session_start();

// ตรวจสอบว่ามีการเข้าสู่ระบบหรือไม่
if (!isset($_SESSION['username'])) {
  // หากไม่ได้เข้าสู่ระบบ ให้ redirect ไปยังหน้า login.php
  header("Location: login_form.html");
  exit; // จบการทำงานของสคริปต์ทันทีหลังจาก redirect
}
include 'condb.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="styles.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>

  <?php include 'navbar.php'; ?>

  <center>
    <img src="banner.png" alt="BANNER" class="center img-responsive">
  </center>
  <table>
    <center>
      <div class="container">
        <div class="row ustify-content-center">
          <div class="row">
          </div>
          <center>
            <h1>ฟอร์มเพิ่มข้อมูล<h1>
          </center>

          <form action="Add_Device.php" method="post" class="form-horizontal">
            <div class="form-group">
              <label for="inputCode_Device" class="<col-md-15> control-label">
                <h3>
                  <center>รหัสอุปกรณ์</center>
                </h3>
              </label>
              <div class="<col-md-12>">
                <input required type="text" name="Code_Device" class="form-control" id="inputCode_Device"
                  placeholder="รหัสอุปกรณ์">
              </div>
            </div>



            <div class="form-group">
              <h3> <label for="inputType_Device">ชนิดอุปกรณ์</label></h3>

              <select required name="Type_Device" id="Type_Device" class="form-control">
                <option value="" selected disabled>ชนิดอุปกรณ์</option>
                <option value="เมาส์(Mouse)">เมาส์(Mouse)</option>
                <option value="จอแสดงผล(Monitor)">จอแสดงผล(Monitor)</option>
                <option value="คีย์บอร์ด(Keyboard)">คีย์บอร์ด(Keyboard)</option>
                <option value="คอมพิวเตอร์(Computer)">คอมพิวเตอร์(Computer)</option>
                <option value="Smartphone">โทรศัพท์(Smartphone)</option>
                <option value="Scanner">เครื่องถ่ายเอกสาร(Scanner)</option>
                <option value="Tablet">แท็บเล็ต(Tablet)</option>
                <option value="Laptop">โน้ตบุ้ค(Laptop)</option>
                <option value="Projector">โปรเจ็คเตอร์(Projector)</option>
                <option value="Printer">เครื่องปริ้น(Printer)</option>
              </select>




              <div class="form-group">
                <h3> <label for="inputRoom">ห้อง</label></h3>

                <select required name="Room" id="Room" class="form-control">
                  <option value="" selected disabled>ห้อง</option>
                  <option value="Com1">Com1</option>
                  <option value="Com2">Com2</option>
                  <option value="Com3">Com3</option>
                  <option value="Com4">Com4</option>
                </select>


              </div>
            </div>

            <br>
            <div class="form-group">
              <div class="col-sm-offset-2 col-sm-8">
                <button class="btn btn-success" type="submit" class="btn btn-default">SAVE</button>
              </div>
            </div>
            <br>
          </form>
        </div>
      </div>
      </div>

  </table>
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="https://code.jquery.com/jquery-1.12.4.min.js"
    integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous">
    </script>
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"
    integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous">
    </script>
  <br>
  </br>
  <center>
    <img src="footer.png" alt="footer" class="center img-responsive">
  </center>
</body>

</html>